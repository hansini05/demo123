package com.college.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Student {

    private int id;
    private String name;
    private String gender;

    @Autowired
    private Certification certification;   // Dependency Injection

    public Student() {
        this.id = 1;
        this.name = "Hansini";
        this.gender = "Female";
    }

    public void display() {
        System.out.println("Student ID   : " + id);
        System.out.println("Name         : " + name);
        System.out.println("Gender       : " + gender);
        System.out.println("Certification: " + certification);
    }
}
