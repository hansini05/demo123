package com.fsad.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Student {

    private int studentId;
    private String name;
    private String course;
    private int year;

    // ✅ Constructor Injection with @Value
    public Student(
            @Value("101") int studentId,
            @Value("Hansini") String name,
            @Value("Spring Framework") String course,
            @Value("3") int year) {

        this.studentId = studentId;
        this.name = name;
        this.course = course;
        this.year = year;
    }

    // ✅ Setter Injection
    @Value("Microservices")
    public void setCourse(String course) {
        this.course = course;
    }

    @Value("4")
    public void setYear(int year) {
        this.year = year;
    }

    public void display() {
        System.out.println("Student ID : " + studentId);
        System.out.println("Name       : " + name);
        System.out.println("Course     : " + course);
        System.out.println("Year       : " + year);
    }
}
